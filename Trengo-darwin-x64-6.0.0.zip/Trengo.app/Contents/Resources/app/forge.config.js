require('dotenv').config()
const notarize = require('./notarize');

module.exports = {
    packagerConfig: {
        "icon": "src/build/icons/icon.icns",
        "osxSign": {
            // "identity": "Apple Development: Lennart Nagel (77VS6677SV)",
            // "identity": "3rd Party Mac Developer Installer: Sector8 (CLV357J4RS)",
            // "identity": "3rd Party Mac Developer Application: Sector8 (CLV357J4RS)",
            // "identity": "Apple Development: Lennart Nagel (77VS6677SV)",
            // "identity": "Apple Distribution: Sector8 (CLV357J4RS)",
            // "identity": "Developer ID Application: Sector8 (CLV357J4RS)",
            "identity": "Developer ID Application: Sector8 (CLV357J4RS)",
            "gatekeeper-assess": false,
            "hardened-runtime": true,
            "entitlements": "entitlements.plist",
            "entitlementsInherit": "entitlements.plist"
        },
        "mas": {
            "hardenedRuntime" : true,
            "gatekeeperAssess": false,
            "entitlements": "entitlements.plist",
            "entitlementsInherit": "entitlements.plist"
        },
        // dir: 'src',
        extraResource: ['child.plist', 'entitlements.plist', 'parent.plist'],
    },
    makers: [
        {
            "name": "@electron-forge/maker-zip",
            "platforms": [
                "darwin"
            ],
            // config: {
            //     keychain:
            // }
            publishers: [
                'github'
            ]
        }
    ],
    // "build": {
    //     "afterSign": "scripts/notarize.js"
    // }
    hooks: {
        // "afterSign": notarize,
        // postPackage: notarize,
        postMake: notarize,
    }
}

// example.forge.config.js
// {
//     packagerConfig: { ... },
//     electronRebuildConfig: { ... },
//     makers: [ ... ],
//         publishers: [ ... ],
//     plugins: [ ... ],
//     hooks: { ... },
//     buildIdentifier: 'my-build'
// }
