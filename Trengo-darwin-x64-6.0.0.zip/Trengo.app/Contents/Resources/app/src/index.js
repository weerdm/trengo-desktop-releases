const { app, BrowserWindow, ipcMain, Menu, powerMonitor, nativeTheme } = require('electron');
const path = require('path');
let mainWindow;
let badge = 0;
const isMac = process.platform === 'darwin'
const isDevelopment = process.env.NODE_ENV !== 'production'

import { autoUpdater } from 'electron-updater';

// Set theme to light mode
nativeTheme.themeSource = 'light';

// Allow development
app.commandLine.appendSwitch('ignore-certificate-errors', 'true');

// Handle creating/removing shortcuts on Windows when installing/uninstalling.
if (require('electron-squirrel-startup')) { // eslint-disable-line global-require
  app.quit();
}

// Context menu
require('electron-context-menu')({
    prepend: (params, browserWindow) => [{
        label: 'Trengo',
        visible: params.mediaType === 'image'
    }]
});

// Handle only one instance
const gotTheLock = app.requestSingleInstanceLock()
if (!gotTheLock) {
  app.quit()
} else {
  app.on('second-instance', (event, commandLine, workingDirectory) => {
    // Someone tried to run a second instance, we should focus our window.
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore()
      mainWindow.focus()
    }
  })
}

const createWindow = () => {
  powerMonitor.on('shutdown', () => {
    app.quit();
  });

  // Create the browser window.
  mainWindow = new BrowserWindow({
    width: 1800,
    height: 1000,
    minWidth: 700,
    minHeight: 700,
    webPreferences: {
        preload: path.join(__dirname, 'preload.js'), // use a preload script
        nodeIntegration: false, // is default value after Electron v5
        contextIsolation: true, // protect against prototype pollution
        enableRemoteModule: false, // turn off remote
    },
  });

  mainWindow.on('close', function (event) {
      mainWindow = null;
  //     if (!app.isQuiting && mainWindow) {
  //         console.log('main Window preventing default');
  //         event.preventDefault()
  //         mainWindow.hide();
  //     }
  });


  // and load the index.html of the app.
  mainWindow.loadURL('https://trengo.test');

  // Open the DevTools.
  // mainWindow.webContents.openDevTools();

  let webContents = mainWindow.webContents;
    webContents.on('will-navigate', function (event, url) {
        if (url.startsWith('https://trengo.test') == false) {
            event.preventDefault();
            require("electron").shell.openExternal(url);
        }
    });
    webContents.on('new-window', function(e, url) {
        e.preventDefault();
        require('electron').shell.openExternal(url);
    });

    Menu.setApplicationMenu(Menu.buildFromTemplate([
    {
        label: 'Trengo',
        submenu: [
          { role: 'about' },
          // { label: 'Check for updates', click: () => { require('electron').autoUpdater.checkForUpdates(); }},
          { type: 'separator'},
          { label: 'Hide Trengo', click: () => { mainWindow.hide(); }},
          { type: 'separator'},
          { label: 'Quit', accelerator: "CmdOrCtrl+Q", click: () => { app.isQuiting = true; app.quit(); } }
        ]
    }, {
      role: 'EditMenu'
    }, {
        label: 'View',
        submenu: [
          { role: 'reload' },
          { role: 'forcereload' },
          { type: 'separator' },
          { role: 'resetzoom' },
          { role: 'zoomin' },
          { role: 'zoomout' },
          { type: 'separator' },
          { role: 'togglefullscreen' },
          // { role: 'toggleDevTools' }
        ]
    }, {
        label: "Window",
        submenu: [
            { label: "Minimize", accelerator: "CmdOrCtrl+H", click() { mainWindow.hide() } },
            { label: "Close", accelerator: "CmdOrCtrl+W", click() { mainWindow.hide() } }
        ]
    }, {
        label: "Help",
        submenu: [
            { label: "Get help", click() { require("electron").shell.openExternal('https://help.trengo.com/');} },
        ]
    }
    ]));
};

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.on('ready', createWindow);
app.on('activate', () => {
    if (mainWindow === null) {
        createWindow();
    } else {
        mainWindow.restore();
        mainWindow.focus();
    }
    app.setBadgeCount(0);
});


// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', () => {
  if (!isMac) {
    app.quit();
  }
});

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and import them here.
ipcMain.on('notify', (event, arg) => {
    badge++;
    app.setBadgeCount(badge);
    if (isMac) {
        app.dock.bounce();
    }
    else {
        mainWindow.flashFrame(true);
    }
});

ipcMain.on('focus', (event, arg) => {
    mainWindow.show();
    app.setBadgeCount(0);
    if (!isMac) {
        mainWindow.flashFrame(false);
    }
});
