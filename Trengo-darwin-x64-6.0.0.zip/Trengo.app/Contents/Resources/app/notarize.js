require('dotenv').config();
const { notarize } = require('electron-notarize');

// Path from here to your build app executable:
const buildOutput = require('path').resolve(
    __dirname,
    'out',
    'Trengo-darwin-x64',
    'Trengo.app'
);

module.exports = function () {
    if (process.platform !== 'darwin') {
        console.log('Not a Mac; skipping notarization');
        return;
    }

    console.log('Notarizing... ');

    return notarize({
        appBundleId: 'com.trengo.desktop',
        appPath: buildOutput,
        appleId: process.env.APPLE_ID,
        appleIdPassword: process.env.APPLE_ID_PASSWORD
    }).catch((e) => {
        console.error(e);
        throw e;
    });
}

// exports.default = async function notarizing(context) {
//     const { electronPlatformName, appOutDir } = context;
//     if (electronPlatformName !== 'darwin') {
//         return;
//     }
//
//     const appName = context.packager.appInfo.productFilename;
//
//     return await notarize({
//         appBundleId: 'com.yourcompany.yourAppId',
//         appPath: `${appOutDir}/${appName}.app`,
//         appleId: process.env.APPLEID,
//         appleIdPassword: process.env.APPLEIDPASS,
//     });
// };